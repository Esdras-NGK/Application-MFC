package mfc;

import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.JTable;

public class FenFormateur {

	private JFrame frame;
	private JTextField textNomF;
	private JTextField textPrenomF;
	private JTextField textTelF;
	private JTextField textAdresseF;
	private JTextField textMailF;
	private JTextField textSpécialiteF;
	private JTextField textIDF;
	private JFrame frmConnexion;
	private JTable table;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FenFormateur window = new FenFormateur();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FenFormateur() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 1700, 1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(255, 128, 0));
		panel.setBounds(0, 0, 1540, 64);
		frame.getContentPane().add(panel);
		
		JLabel lblGestionDesFormateurs = new JLabel("Gestion des  Formateurs");
		lblGestionDesFormateurs.setForeground(Color.WHITE);
		lblGestionDesFormateurs.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblGestionDesFormateurs.setBackground(new Color(255, 128, 0));
		lblGestionDesFormateurs.setBounds(769, 10, 330, 50);
		panel.add(lblGestionDesFormateurs);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.GRAY);
		panel_1.setBounds(0, 65, 300, 780);
		frame.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_3_1_1_1 = new JLabel("Sessions");
		lblNewLabel_3_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3_1_1_1.setBounds(348, 383, 200, 30);
		panel_1.add(lblNewLabel_3_1_1_1);
		
		JButton btnNewButton_3_1_1 = new JButton("Sessions");
		btnNewButton_3_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenSessions window = new FenSessions();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnNewButton_3_1_1.setForeground(Color.WHITE);
		btnNewButton_3_1_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3_1_1.setBackground(Color.GRAY);
		btnNewButton_3_1_1.setBounds(59, 510, 180, 80);
		panel_1.add(btnNewButton_3_1_1);
		
		JButton btnNewButton_3_1_2 = new JButton("Formation");
		btnNewButton_3_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenFormations window = new FenFormations();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnNewButton_3_1_2.setForeground(Color.WHITE);
		btnNewButton_3_1_2.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3_1_2.setBackground(Color.GRAY);
		btnNewButton_3_1_2.setBounds(59, 19, 180, 80);
		panel_1.add(btnNewButton_3_1_2);
		
		JButton btnNewButton_3_1_2_1 = new JButton("Stagiaires");
		btnNewButton_3_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenStagiaire window = new FenStagiaire();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnNewButton_3_1_2_1.setForeground(Color.WHITE);
		btnNewButton_3_1_2_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3_1_2_1.setBackground(Color.GRAY);
		btnNewButton_3_1_2_1.setBounds(59, 125, 180, 80);
		panel_1.add(btnNewButton_3_1_2_1);
		
		JButton btnNewButton_3_1 = new JButton("");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3_1.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre (2).jpg"));
		btnNewButton_3_1.setForeground(Color.WHITE);
		btnNewButton_3_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3_1.setBackground(Color.GRAY);
		btnNewButton_3_1.setBounds(59, 235, 200, 200);
		panel_1.add(btnNewButton_3_1);
		
		JLabel lblNewLabel_3 = new JLabel("Formateur");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(59, 455, 200, 30);
		panel_1.add(lblNewLabel_3);
		
		JButton btnQuitter_1 = new JButton("Quitter");
		btnQuitter_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 // Code pour passer à une autre fenêtre après la connexion réussie
            	EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {

                            MenuPrincipal window = new MenuPrincipal();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnQuitter_1.setForeground(Color.BLACK);
		btnQuitter_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnQuitter_1.setBackground(Color.WHITE);
		btnQuitter_1.setBounds(59, 623, 180, 80);
		panel_1.add(btnQuitter_1);
		
		JLabel lblNomstagiaire = new JLabel("Nom_Formateur");
		lblNomstagiaire.setForeground(Color.WHITE);
		lblNomstagiaire.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNomstagiaire.setBounds(313, 98, 185, 40);
		frame.getContentPane().add(lblNomstagiaire);
		
		JLabel lblStagiaire = new JLabel("Prenom_Formateur");
		lblStagiaire.setForeground(Color.WHITE);
		lblStagiaire.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblStagiaire.setBounds(313, 148, 185, 40);
		frame.getContentPane().add(lblStagiaire);
		
		JLabel lblTel = new JLabel("Tel Formateur");
		lblTel.setForeground(Color.WHITE);
		lblTel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTel.setBounds(313, 198, 185, 40);
		frame.getContentPane().add(lblTel);
		
		JLabel lblAdresse = new JLabel("Adresse Formateurs");
		lblAdresse.setForeground(Color.WHITE);
		lblAdresse.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblAdresse.setBounds(313, 248, 185, 40);
		frame.getContentPane().add(lblAdresse);
		
		JLabel lblMail = new JLabel("Mail Formateurs");
		lblMail.setForeground(Color.WHITE);
		lblMail.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblMail.setBounds(313, 298, 185, 40);
		frame.getContentPane().add(lblMail);
		
		JLabel lblEntreprise = new JLabel("Specialite Formateurs");
		lblEntreprise.setForeground(Color.WHITE);
		lblEntreprise.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEntreprise.setBounds(313, 348, 185, 40);
		frame.getContentPane().add(lblEntreprise);
		
		JLabel lblIdLivre = new JLabel("Id Formateurs");
		lblIdLivre.setForeground(Color.WHITE);
		lblIdLivre.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblIdLivre.setBounds(328, 498, 185, 40);
		frame.getContentPane().add(lblIdLivre);
		
		textNomF = new JTextField();
		textNomF.setColumns(10);
		textNomF.setBounds(523, 112, 200, 19);
		frame.getContentPane().add(textNomF);
		
		textPrenomF = new JTextField();
		textPrenomF.setColumns(10);
		textPrenomF.setBounds(523, 161, 200, 19);
		frame.getContentPane().add(textPrenomF);
		
		textTelF = new JTextField();
		textTelF.setColumns(10);
		textTelF.setBounds(523, 211, 200, 19);
		frame.getContentPane().add(textTelF);
		
		textAdresseF = new JTextField();
		textAdresseF.setColumns(10);
		textAdresseF.setBounds(523, 261, 200, 19);
		frame.getContentPane().add(textAdresseF);
		
		textMailF = new JTextField();
		textMailF.setColumns(10);
		textMailF.setBounds(523, 311, 200, 19);
		frame.getContentPane().add(textMailF);
		
		textSpécialiteF = new JTextField();
		textSpécialiteF.setColumns(10);
		textSpécialiteF.setBounds(523, 361, 200, 19);
		frame.getContentPane().add(textSpécialiteF);
		
		textIDF = new JTextField();
		textIDF.setColumns(10);
		textIDF.setBounds(523, 511, 200, 19);
		frame.getContentPane().add(textIDF);
		
		JButton btnNewButton = new JButton("Enregistrer");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// Connexion et insertion dans la base de données
				try {
					
		            String jdbcUrl = "jdbc:mysql://localhost/mfc";
		            String user = "root";
		            String password = "Root";

		            // Chargez le pilote JDBC et établissez la connexion
		            Class.forName("com.mysql.cj.jdbc.Driver");
		            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
		                System.out.println("Connecté à la base de données MySQL");

		                // Vous pouvez exécuter vos requêtes SQL ici
		                // Par exemple, insérer des données dans une table :
		                String sql = "INSERT INTO intervenants__formateurs(Nom_FOR, Prenom_FOR, Tel_FOR, Adresse_FOR, Mail_FOR, Specialite_FOR) VALUES (?,?,?,?,?,?)";
		                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
		                    preparedStatement.setString(1, textNomF.getText());
		                    preparedStatement.setString(2, textPrenomF.getText());
		                    preparedStatement.setString(3, textTelF.getText());
		                    preparedStatement.setString(4, textAdresseF.getText());
		                    preparedStatement.setString(5, textMailF.getText());
		                    preparedStatement.setString(6, textSpécialiteF.getText());
		                    

		                    int rowsAffected = preparedStatement.executeUpdate();
		                    JOptionPane.showMessageDialog(frame," ligne(s) affectée(s)."+ rowsAffected );
		                    System.out.println("Lignes affectées : " + rowsAffected);
		                    
		    				
		                     //FenStagiaire.this.dispose(); //Fermer la fenetre active

		    				
		                } catch (SQLException e3) {
		                    e3.printStackTrace();
		                }
		            } catch (SQLException e2) {
		                e2.printStackTrace();
		                System.out.println("Erreur lors de la connexion");
		            }
		        } catch (ClassNotFoundException e1) {
		            e1.printStackTrace();
		            System.out.println("Erreur lors du chargement du pilote JDBC");
		        }
				
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton.setBackground(new Color(255, 128, 0));
		btnNewButton.setBounds(324, 557, 180, 80);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Modifier");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmConnexion = new JFrame("Modifier");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Etes-vous de vouloir Modifier  ces données ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					// Connexion et insertion dans la base de données
					try {
						
			            String jdbcUrl = "jdbc:mysql://localhost/mfc";
			            String user = "root";
			            String password = "Root";

			            // Chargez le pilote JDBC et établissez la connexion
			            Class.forName("com.mysql.cj.jdbc.Driver");
			            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
			                System.out.println("Connecté à la base de données MySQL");

			                // Vous pouvez exécuter vos requêtes SQL ici
			                // Par exemple, insérer des données dans une table :
			                String sql = "UPDATE intervenants__formateurs SET Nom_FOR=?,Prenom_FOR=?,Tel_FOR=?,Adresse_FOR=?,Mail_FOR=?,Specialite_FOR=? WHERE IDFOR=?"; //Assurez-vous que NomS est unique pour identifier la ligne à mettre à jour
			                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			                    preparedStatement.setString(1, textNomF.getText());
			                    preparedStatement.setString(2, textPrenomF.getText());
			                    preparedStatement.setString(3, textTelF.getText());
			                    preparedStatement.setString(4, textAdresseF.getText());
			                    preparedStatement.setString(5, textMailF.getText());
			                    preparedStatement.setString(6, textSpécialiteF.getText()); 
			                    preparedStatement.setString(9, textIDF.getText()); // NomS utilisé pour identifier la ligne à mettre à jour


			                    int rowsAffected = preparedStatement.executeUpdate();
			                    JOptionPane.showMessageDialog(frame," ligne(s) affectée(s)."+ rowsAffected );


			    				
			                    System.out.println("Lignes affectées : " + rowsAffected);

			                    
			    				MenuPrincipal fenetreMenu = new MenuPrincipal();  // Passer d'une fenêtre à une autre
			    				fenetreMenu.setVisible(true);
			                     //FenStagiaire.this.dispose(); //Fermer la fenetre active

			    				
			                } catch (SQLException e3) {
			                    e3.printStackTrace();
			                }
			            } catch (SQLException e2) {
			                e2.printStackTrace();
			                System.out.println("Erreur lors de la connexion");
			            }
			        } catch (ClassNotFoundException e1) {
			            e1.printStackTrace();
			            System.out.println("Erreur lors du chargement du pilote JDBC");
			        }
				};
				
				
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_2.setBackground(new Color(255, 128, 0));
		btnNewButton_2.setBounds(542, 557, 180, 80);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmConnexion = new JFrame("Supprimer");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Voulez-vous Supprimer ces données ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					// Connexion et insertion dans la base de données
					try {
						
			            String jdbcUrl = "jdbc:mysql://localhost/mfc";
			            String user = "root";
			            String password = "Root";

			            // Chargez le pilote JDBC et établissez la connexion
			            Class.forName("com.mysql.cj.jdbc.Driver");
			            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
			                System.out.println("Connecté à la base de données MySQL");

			                // Vous pouvez exécuter vos requêtes SQL ici
			                // Par exemple, insérer des données dans une table :
			                String sql = "DELETE FROM intervenants__formateurs WHERE IDFOR=?";
			                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			                    preparedStatement.setString(1, textIDF.getText()); // Utilisez un identifiant unique pour la suppression
			                    

			                    int rowsAffected2 = preparedStatement.executeUpdate();
			                    JOptionPane.showMessageDialog(frame," ligne(s) affectée(s)."+ rowsAffected2 );

			                    System.out.println("Lignes affectées : " + rowsAffected2);
			                    
			    				MenuPrincipal fenetreMenu = new MenuPrincipal();  // Passer d'une fenêtre à une autre
			    				fenetreMenu.setVisible(true);
			                     //FenStagiaire.this.dispose(); //Fermer la fenetre active

			    				
			                } catch (SQLException e3) {
			                    e3.printStackTrace();
			                }
			            } catch (SQLException e2) {
			                e2.printStackTrace();
			                System.out.println("Erreur lors de la connexion");
			            }
			        } catch (ClassNotFoundException e1) {
			            e1.printStackTrace();
			            System.out.println("Erreur lors du chargement du pilote JDBC");
			        }
				};
				
				
			}
		});
		btnSupprimer.setForeground(Color.WHITE);
		btnSupprimer.setFont(new Font("Dialog", Font.BOLD, 15));
		btnSupprimer.setBackground(new Color(255, 128, 0));
		btnSupprimer.setBounds(324, 671, 180, 80);
		frame.getContentPane().add(btnSupprimer);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmConnexion = new JFrame("Quitter");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Voulez-vous quitter l'application ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				};
				
				
			}
		});
		btnQuitter.setForeground(Color.WHITE);
		btnQuitter.setFont(new Font("Dialog", Font.BOLD, 15));
		btnQuitter.setBackground(new Color(255, 128, 0));
		btnQuitter.setBounds(542, 671, 180, 80);
		frame.getContentPane().add(btnQuitter);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(817, 112, 700, 400);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnRecheche = new JButton("Actualiser");
		btnRecheche.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
		            String jdbcUrl = "jdbc:mysql://localhost/mfc";
		            String user = "root";
		            String password = "Root";

		            Class.forName("com.mysql.cj.jdbc.Driver");
		            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
		                System.out.println("Connecté à la base de données MySQL");

		                String sql = "SELECT * FROM intervenants__formateurs"; // Supprimez 'order by IDS' si ce n'est pas nécessaire
		                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
		                    ResultSet resultSet = preparedStatement.executeQuery();

		                    // Créer un DefaultTableModel pour stocker les données
		                    DefaultTableModel model = new DefaultTableModel();
		                 // Ajouter les colonnes avec les titres prédéfinis
		                    String[] columnTitles = {"IDFOR", "Nom_FOR", "Prenom_FOR", "Tel_FOR", "Adresse_FOR", "Mail_FOR", "Specialite_FOR"};
		                    model.setColumnIdentifiers(columnTitles);

		                    // Ajouter les lignes
		                    while (resultSet.next()) {
		                        Object[] row = {
		                            resultSet.getInt("IDFOR"),
		                            resultSet.getString("Nom_FOR"),
		                            resultSet.getString("Prenom_FOR"),
		                            resultSet.getString("Tel_FOR"),
		                            resultSet.getString("Adresse_FOR"),
		                            resultSet.getString("Mail_FOR"),
		                            resultSet.getString("Specialite_FOR")
		                            
		                        };
		                        model.addRow(row);
		                    }
		                    // Mettre à jour le modèle de table existant
		                    table.setModel(model);
		                } catch (SQLException e3) {
		                    e3.printStackTrace();
		                }
		            } catch (SQLException e2) {
		                e2.printStackTrace();
		                System.out.println("Erreur lors de la connexion");
		            }
		        } catch (ClassNotFoundException e1) {
		            e1.printStackTrace();
		            System.out.println("Erreur lors du chargement du pilote JDBC");
		        }	
				
				
			}
		});
		btnRecheche.setForeground(Color.WHITE);
		btnRecheche.setFont(new Font("Dialog", Font.BOLD, 15));
		btnRecheche.setBackground(new Color(255, 128, 0));
		btnRecheche.setBounds(1115, 671, 180, 80);
		frame.getContentPane().add(btnRecheche);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(346, 465, 100, 2);
		frame.getContentPane().add(separator);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre.jpg"));
		lblNewLabel.setBackground(Color.BLACK);
		lblNewLabel.setBounds(0, 0, 1540, 845);
		frame.getContentPane().add(lblNewLabel);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
