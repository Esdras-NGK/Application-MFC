package mfc;

import java.awt.EventQueue;



import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.Window;
//La connexion à la base de données
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

import com.mysql.cj.xdevapi.Result;
//
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;


public class FenStagiaire {

	private JFrame frame;
	private JTextField textnom;
	private JTextField textPrenom;
	private JTextField textTel;
	private JTextField textAdresse;
	private JTextField textMail;
	private JTextField textEntrepris;
	private JPasswordField passwordMdp;
	private JPasswordField passwordCMdp;
	private JTextField textID;
	private JFrame frmConnexion;
	private JTable table;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FenStagiaire window = new FenStagiaire();
					window.frame.setVisible(true);
					window.getFrame().setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FenStagiaire() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\esdra\\Downloads\\Blue Modern Free Academy Logo.png"));
		frame.setBounds(0, 0, 1540, 1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1540, 64);
		panel.setLayout(null);
		panel.setBackground(new Color(255, 128, 0));
		frame.getContentPane().add(panel);
		
		JLabel lblTitreStagiaire = new JLabel("Gestion des Stagiaire");
		lblTitreStagiaire.setForeground(Color.WHITE);
		lblTitreStagiaire.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblTitreStagiaire.setBackground(new Color(255, 128, 0));
		lblTitreStagiaire.setBounds(769, 10, 300, 50);
		panel.add(lblTitreStagiaire);
		
		JLabel lblNomstagiaire = new JLabel("Nom du Stagiaire");
		lblNomstagiaire.setBounds(313, 98, 185, 40);
		lblNomstagiaire.setForeground(Color.WHITE);
		lblNomstagiaire.setFont(new Font("Dialog", Font.PLAIN, 16));
		frame.getContentPane().add(lblNomstagiaire);
		
		JLabel lblStagiaire = new JLabel("Prenom Stagiaire");
		lblStagiaire.setBounds(313, 148, 185, 40);
		lblStagiaire.setForeground(Color.WHITE);
		lblStagiaire.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblStagiaire);
		
		JLabel lblTel = new JLabel("Tel Stagiare");
		lblTel.setBounds(313, 198, 185, 40);
		lblTel.setForeground(Color.WHITE);
		lblTel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblTel);
		
		JLabel lblAdresse = new JLabel("Adresse Stagiare");
		lblAdresse.setBounds(313, 248, 185, 40);
		lblAdresse.setForeground(Color.WHITE);
		lblAdresse.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblAdresse);
		
		JLabel lblMail = new JLabel("Mail Stagiare");
		lblMail.setBounds(313, 298, 185, 40);
		lblMail.setForeground(Color.WHITE);
		lblMail.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblMail);
		
		JLabel lblEntreprise = new JLabel("Entreprise ");
		lblEntreprise.setBounds(313, 348, 185, 40);
		lblEntreprise.setForeground(Color.WHITE);
		lblEntreprise.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblEntreprise);
		
		JLabel lblMdp = new JLabel("Mot de passe");
		lblMdp.setBounds(313, 398, 185, 40);
		lblMdp.setForeground(Color.WHITE);
		lblMdp.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblMdp);
		
		JLabel lblCmdp = new JLabel("Confirmé le  mot de passe");
		lblCmdp.setBounds(313, 448, 200, 40);
		lblCmdp.setForeground(Color.WHITE);
		lblCmdp.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblCmdp);
		
		textnom = new JTextField();
		textnom.setBounds(523, 112, 200, 19);
		textnom.setColumns(10);
		frame.getContentPane().add(textnom);
		
		textPrenom = new JTextField();
		textPrenom.setBounds(523, 161, 200, 19);
		textPrenom.setColumns(10);
		frame.getContentPane().add(textPrenom);
		
		textTel = new JTextField();
		textTel.setBounds(523, 211, 200, 19);
		textTel.setColumns(10);
		frame.getContentPane().add(textTel);
		
		textAdresse = new JTextField();
		textAdresse.setBounds(523, 261, 200, 19);
		textAdresse.setColumns(10);
		frame.getContentPane().add(textAdresse);
		
		textMail = new JTextField();
		textMail.setBounds(523, 311, 200, 19);
		textMail.setColumns(10);
		frame.getContentPane().add(textMail);
		
		textEntrepris = new JTextField();
		textEntrepris.setBounds(523, 361, 200, 19);
		textEntrepris.setColumns(10);
		frame.getContentPane().add(textEntrepris);
		
		passwordMdp = new JPasswordField();
		passwordMdp.setBounds(523, 411, 200, 19);
		frame.getContentPane().add(passwordMdp);
		
		passwordCMdp = new JPasswordField();
		passwordCMdp.setBounds(523, 461, 200, 19);
		frame.getContentPane().add(passwordCMdp);
		
		JButton btnNewButton = new JButton("Enregistrer");
		btnNewButton.setBounds(324, 557, 180, 80);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				// Connexion et insertion dans la base de données
				try {
					
		            String jdbcUrl = "jdbc:mysql://localhost/mfc";
		            String user = "root";
		            String password = "Root";

		            // Chargez le pilote JDBC et établissez la connexion
		            Class.forName("com.mysql.cj.jdbc.Driver");
		            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
		                System.out.println("Connecté à la base de données MySQL");

		                // Vous pouvez exécuter vos requêtes SQL ici
		                // Par exemple, insérer des données dans une table :
		                String sql = "INSERT INTO stagiaires(NomS, PrenomS, Tel_S, Adresse_S, Mail_S, Entreprise, mdp, cmdp) VALUES (?,?,?,?,?,?,?,?)";
		                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
		                    preparedStatement.setString(1, textnom.getText());
		                    preparedStatement.setString(2, textPrenom.getText());
		                    preparedStatement.setString(3, textTel.getText());
		                    preparedStatement.setString(4, textAdresse.getText());
		                    preparedStatement.setString(5, textMail.getText());
		                    preparedStatement.setString(6, textEntrepris.getText());
		                    preparedStatement.setString(7, new String(passwordMdp.getPassword()));
		                    preparedStatement.setString(8, new String(passwordCMdp.getPassword()));

		                    int rowsAffected = preparedStatement.executeUpdate();
		                    
		                    System.out.println("Lignes affectées : " + rowsAffected);
		                    
		    				MenuPrincipal fenetreMenu = new MenuPrincipal();  // Passer d'une fenêtre à une autre
		    				fenetreMenu.setVisible(true);
		                     //FenStagiaire.this.dispose(); //Fermer la fenetre active

		    				
		                } catch (SQLException e3) {
		                    e3.printStackTrace();
		                }
		            } catch (SQLException e2) {
		                e2.printStackTrace();
		                System.out.println("Erreur lors de la connexion");
		            }
		        } catch (ClassNotFoundException e1) {
		            e1.printStackTrace();
		            System.out.println("Erreur lors du chargement du pilote JDBC");
		        }
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton.setBackground(new Color(255, 128, 0));
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Modifier");
		btnNewButton_2.setBounds(542, 557, 180, 80);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmConnexion = new JFrame("Modifier");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Etes-vous de vouloir Modifier  ces données ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					// Connexion et insertion dans la base de données
					try {
						
			            String jdbcUrl = "jdbc:mysql://localhost/mfc";
			            String user = "root";
			            String password = "Root";

			            // Chargez le pilote JDBC et établissez la connexion
			            Class.forName("com.mysql.cj.jdbc.Driver");
			            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
			                System.out.println("Connecté à la base de données MySQL");

			                // Vous pouvez exécuter vos requêtes SQL ici
			                // Par exemple, insérer des données dans une table :
			                String sql = "UPDATE stagiaires SET NomS=?,PrenomS=?,Tel_S=?,Adresse_S=?,Mail_S=?,Entreprise=?,mdp=?,cmdp=? WHERE IDS=?"; //Assurez-vous que NomS est unique pour identifier la ligne à mettre à jour
			                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			                    preparedStatement.setString(1, textnom.getText());
			                    preparedStatement.setString(2, textPrenom.getText());
			                    preparedStatement.setString(3, textTel.getText());
			                    preparedStatement.setString(4, textAdresse.getText());
			                    preparedStatement.setString(5, textMail.getText());
			                    preparedStatement.setString(6, textEntrepris.getText());
			                    preparedStatement.setString(7, new String(passwordMdp.getPassword()));
			                    preparedStatement.setString(8, new String(passwordCMdp.getPassword()));
			                    preparedStatement.setString(9, textID.getText()); // NomS utilisé pour identifier la ligne à mettre à jour


			                    int rowsAffected = preparedStatement.executeUpdate();
			                    JOptionPane.showMessageDialog(frame," ligne(s) affectée(s)."+ rowsAffected );


			    				
			                    System.out.println("Lignes affectées : " + rowsAffected);

			                    
			    				MenuPrincipal fenetreMenu = new MenuPrincipal();  // Passer d'une fenêtre à une autre
			    				fenetreMenu.setVisible(true);
			                     //FenStagiaire.this.dispose(); //Fermer la fenetre active

			    				
			                } catch (SQLException e3) {
			                    e3.printStackTrace();
			                }
			            } catch (SQLException e2) {
			                e2.printStackTrace();
			                System.out.println("Erreur lors de la connexion");
			            }
			        } catch (ClassNotFoundException e1) {
			            e1.printStackTrace();
			            System.out.println("Erreur lors du chargement du pilote JDBC");
			        }
				};
				
				
				
				
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_2.setBackground(new Color(255, 128, 0));
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.setBounds(324, 671, 180, 80);
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmConnexion = new JFrame("Supprimer");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Voulez-vous Supprimer ces données ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					// Connexion et insertion dans la base de données
					try {
						
			            String jdbcUrl = "jdbc:mysql://localhost/mfc";
			            String user = "root";
			            String password = "Root";

			            // Chargez le pilote JDBC et établissez la connexion
			            Class.forName("com.mysql.cj.jdbc.Driver");
			            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
			                System.out.println("Connecté à la base de données MySQL");

			                // Vous pouvez exécuter vos requêtes SQL ici
			                // Par exemple, insérer des données dans une table :
			                String sql = "DELETE FROM stagiaires WHERE IDS=?";
			                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			                    preparedStatement.setString(1, textID.getText()); // Utilisez un identifiant unique pour la suppression
			                    

			                    int rowsAffected2 = preparedStatement.executeUpdate();
			                    JOptionPane.showMessageDialog(frame," ligne(s) affectée(s)."+ rowsAffected2 );

			                    System.out.println("Lignes affectées : " + rowsAffected2);
			                    
			    				MenuPrincipal fenetreMenu = new MenuPrincipal();  // Passer d'une fenêtre à une autre
			    				fenetreMenu.setVisible(true);
			                     //FenStagiaire.this.dispose(); //Fermer la fenetre active

			    				
			                } catch (SQLException e3) {
			                    e3.printStackTrace();
			                }
			            } catch (SQLException e2) {
			                e2.printStackTrace();
			                System.out.println("Erreur lors de la connexion");
			            }
			        } catch (ClassNotFoundException e1) {
			            e1.printStackTrace();
			            System.out.println("Erreur lors du chargement du pilote JDBC");
			        }
				};
				
				
				
			}
		});
		btnSupprimer.setForeground(Color.WHITE);
		btnSupprimer.setFont(new Font("Dialog", Font.BOLD, 15));
		btnSupprimer.setBackground(new Color(255, 128, 0));
		frame.getContentPane().add(btnSupprimer);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.setBounds(542, 671, 180, 80);
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmConnexion = new JFrame("Quitter");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Voulez-vous quitter l'application ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				};

			}
		});
		btnQuitter.setForeground(Color.WHITE);
		btnQuitter.setFont(new Font("Dialog", Font.BOLD, 15));
		btnQuitter.setBackground(new Color(255, 128, 0));
		frame.getContentPane().add(btnQuitter);
		
		JLabel lblIdLivre = new JLabel("Id stagiaire");
		lblIdLivre.setBounds(328, 498, 185, 40);
		lblIdLivre.setForeground(Color.WHITE);
		lblIdLivre.setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().add(lblIdLivre);
		
		textID = new JTextField();
		textID.setBounds(523, 511, 200, 19);
		textID.setColumns(10);
		frame.getContentPane().add(textID);
		
		JButton btnRecheche = new JButton("Actualiser");
		btnRecheche.setBounds(1055, 647, 180, 80);
		btnRecheche.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
		            String jdbcUrl = "jdbc:mysql://localhost/mfc";
		            String user = "root";
		            String password = "Root";

		            Class.forName("com.mysql.cj.jdbc.Driver");
		            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
		                System.out.println("Connecté à la base de données MySQL");

		                String sql = "SELECT * FROM stagiaires"; // Supprimez 'order by IDS' si ce n'est pas nécessaire
		                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
		                    ResultSet resultSet = preparedStatement.executeQuery();

		                    // Créer un DefaultTableModel pour stocker les données
		                    DefaultTableModel model = new DefaultTableModel();
		                 // Ajouter les colonnes avec les titres prédéfinis
		                    String[] columnTitles = {"IDS", "NomS", "PrenomS", "Tel_S", "Adresse_S", "Mail_S", "Entreprise","mdp","cmdp"};
		                    model.setColumnIdentifiers(columnTitles);

		                    // Ajouter les lignes
		                    while (resultSet.next()) {
		                        Object[] row = {
		                            resultSet.getInt("IDS"),
		                            resultSet.getString("NomS"),
		                            resultSet.getString("PrenomS"),
		                            resultSet.getString("Tel_S"),
		                            resultSet.getString("Adresse_S"),
		                            resultSet.getString("Mail_S"),
		                            resultSet.getString("Entreprise"),
		                            resultSet.getString("mdp"),
		                            resultSet.getString("cmdp")
		                        };
		                        model.addRow(row);
		                    }
		                    // Mettre à jour le modèle de table existant
		                    table.setModel(model);
		                } catch (SQLException e3) {
		                    e3.printStackTrace();
		                }
		            } catch (SQLException e2) {
		                e2.printStackTrace();
		                System.out.println("Erreur lors de la connexion");
		            }
		        } catch (ClassNotFoundException e1) {
		            e1.printStackTrace();
		            System.out.println("Erreur lors du chargement du pilote JDBC");
		        }				
				
			}
			
		});
		btnRecheche.setForeground(Color.WHITE);
		btnRecheche.setFont(new Font("Dialog", Font.BOLD, 15));
		btnRecheche.setBackground(new Color(255, 128, 0));
		frame.getContentPane().add(btnRecheche);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 65, 300, 780);
		panel_1.setLayout(null);
		panel_1.setBackground(Color.GRAY);
		frame.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_3_1_1_1 = new JLabel("Sessions");
		lblNewLabel_3_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3_1_1_1.setBounds(348, 383, 200, 30);
		panel_1.add(lblNewLabel_3_1_1_1);
		
		JButton btnNewButton_3_1 = new JButton("Formateurs ");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenFormateur window = new FenFormateur();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });

			}
		});
		btnNewButton_3_1.setForeground(Color.WHITE);
		btnNewButton_3_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3_1.setBackground(Color.GRAY);
		btnNewButton_3_1.setBounds(59, 392, 180, 80);
		panel_1.add(btnNewButton_3_1);
		
		JButton btnNewButton_3_1_1 = new JButton("Sessions");
		btnNewButton_3_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenSessions window = new FenSessions();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnNewButton_3_1_1.setForeground(Color.WHITE);
		btnNewButton_3_1_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3_1_1.setBackground(Color.GRAY);
		btnNewButton_3_1_1.setBounds(59, 510, 180, 80);
		panel_1.add(btnNewButton_3_1_1);
		
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre (3).jpg"));
		btnNewButton_3.setBounds(59, 124, 200, 200);
		panel_1.add(btnNewButton_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Stagiaires ");
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3_1.setBounds(59, 352, 200, 30);
		panel_1.add(lblNewLabel_3_1);
		
		JButton btnNewButton_3_1_2 = new JButton("Formation");
		btnNewButton_3_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenFormations window = new FenFormations();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnNewButton_3_1_2.setForeground(Color.WHITE);
		btnNewButton_3_1_2.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3_1_2.setBackground(Color.GRAY);
		btnNewButton_3_1_2.setBounds(59, 19, 180, 80);
		panel_1.add(btnNewButton_3_1_2);
		
		JButton btnQuitter_1 = new JButton("Quitter");
		btnQuitter_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 // Code pour passer à une autre fenêtre après la connexion réussie
            	EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                            frame.dispose();

                            MenuPrincipal window = new MenuPrincipal();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnQuitter_1.setForeground(Color.BLACK);
		btnQuitter_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnQuitter_1.setBackground(Color.WHITE);
		btnQuitter_1.setBounds(59, 627, 180, 80);
		panel_1.add(btnQuitter_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(780, 112, 700, 380);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 1540, 845);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre.jpg"));
		lblNewLabel.setBackground(Color.BLACK);
		frame.getContentPane().add(lblNewLabel);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
