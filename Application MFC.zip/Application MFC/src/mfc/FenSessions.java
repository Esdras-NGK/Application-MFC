package mfc;

import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class FenSessions {

	private JFrame frame;
	private JTextField textHoraireS;
	private JTextField textDateDebut;
	private JTextField textDateFin;
	private JTextField textIDSalle;
	private JTextField textIDSession;
	private JFrame frmConnexion;
	private JTable table;



	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FenSessions window = new FenSessions();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FenSessions() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 1700, 1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(255, 128, 0));
		panel.setBounds(0, 0, 1540, 64);
		frame.getContentPane().add(panel);
		
		JLabel lblGestionDesSessions = new JLabel("Gestion des Sessions");
		lblGestionDesSessions.setForeground(Color.WHITE);
		lblGestionDesSessions.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblGestionDesSessions.setBackground(new Color(255, 128, 0));
		lblGestionDesSessions.setBounds(769, 10, 300, 50);
		panel.add(lblGestionDesSessions);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.GRAY);
		panel_1.setBounds(0, 65, 300, 780);
		frame.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_3_1_1_1 = new JLabel("Sessions");
		lblNewLabel_3_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3_1_1_1.setBounds(348, 383, 200, 30);
		panel_1.add(lblNewLabel_3_1_1_1);
		
		JButton btnNewButton_3_2 = new JButton("Formation");
		btnNewButton_3_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenFormations window = new FenFormations();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnNewButton_3_2.setForeground(Color.WHITE);
		btnNewButton_3_2.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3_2.setBackground(Color.GRAY);
		btnNewButton_3_2.setBounds(59, 24, 180, 80);
		panel_1.add(btnNewButton_3_2);
		
		JButton btnNewButton_3 = new JButton("Stagiaires ");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenStagiaire window = new FenStagiaire();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3.setBackground(Color.GRAY);
		btnNewButton_3.setBounds(59, 134, 180, 80);
		panel_1.add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("Formateurs ");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenFormateur window = new FenFormateur();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnNewButton_3_1.setForeground(Color.WHITE);
		btnNewButton_3_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_3_1.setBackground(Color.GRAY);
		btnNewButton_3_1.setBounds(59, 248, 180, 80);
		panel_1.add(btnNewButton_3_1);
		
		JButton btnNewButton_3_3 = new JButton("");
		btnNewButton_3_3.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre (1).jpg"));
		btnNewButton_3_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3_3.setBounds(59, 358, 200, 200);
		panel_1.add(btnNewButton_3_3);
		
		JLabel lblNewLabel_3 = new JLabel("Sessions");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(59, 579, 200, 30);
		panel_1.add(lblNewLabel_3);
		
		JButton btnQuitter_1 = new JButton("Quitter");
		btnQuitter_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 // Code pour passer à une autre fenêtre après la connexion réussie
            	EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {

                            frame.dispose();

                            MenuPrincipal window = new MenuPrincipal();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		btnQuitter_1.setForeground(Color.BLACK);
		btnQuitter_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnQuitter_1.setBackground(Color.WHITE);
		btnQuitter_1.setBounds(59, 630, 180, 80);
		panel_1.add(btnQuitter_1);
		
		JLabel lblDescriptionf = new JLabel("Horaire Sessions");
		lblDescriptionf.setForeground(Color.WHITE);
		lblDescriptionf.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblDescriptionf.setBounds(361, 129, 185, 40);
		frame.getContentPane().add(lblDescriptionf);
		
		JLabel lblIntitul = new JLabel("Date de debut");
		lblIntitul.setForeground(Color.WHITE);
		lblIntitul.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblIntitul.setBounds(361, 179, 185, 40);
		frame.getContentPane().add(lblIntitul);
		
		JLabel lblTarifFormation = new JLabel("Date de fin");
		lblTarifFormation.setForeground(Color.WHITE);
		lblTarifFormation.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTarifFormation.setBounds(361, 229, 185, 40);
		frame.getContentPane().add(lblTarifFormation);
		
		JLabel lblDureef = new JLabel("IDSALLE");
		lblDureef.setForeground(Color.WHITE);
		lblDureef.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDureef.setBounds(361, 279, 185, 40);
		frame.getContentPane().add(lblDureef);
		
		textHoraireS = new JTextField();
		textHoraireS.setColumns(10);
		textHoraireS.setBounds(571, 143, 200, 19);
		frame.getContentPane().add(textHoraireS);
		
		textDateDebut = new JTextField();
		textDateDebut.setColumns(10);
		textDateDebut.setBounds(571, 192, 200, 19);
		frame.getContentPane().add(textDateDebut);
		
		textDateFin = new JTextField();
		textDateFin.setColumns(10);
		textDateFin.setBounds(571, 242, 200, 19);
		frame.getContentPane().add(textDateFin);
		
		textIDSalle = new JTextField();
		textIDSalle.setColumns(10);
		textIDSalle.setBounds(571, 292, 200, 19);
		frame.getContentPane().add(textIDSalle);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(387, 321, 374, 9);
		frame.getContentPane().add(separator);
		
		JButton btnEnregistrer = new JButton("Enregistrer");
		btnEnregistrer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// Connexion et insertion dans la base de données
				try {
					
		            String jdbcUrl = "jdbc:mysql://localhost/mfc";
		            String user = "root";
		            String password = "Root";

		            // Chargez le pilote JDBC et établissez la connexion
		            Class.forName("com.mysql.cj.jdbc.Driver");
		            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
		                System.out.println("Connecté à la base de données MySQL");

		                // Vous pouvez exécuter vos requêtes SQL ici
		                // Par exemple, insérer des données dans une table :
		                String sql = "INSERT INTO sessions_de_formation( Horaire_SE, Date_de_debut, Date_de_fin, IDSALLE) VALUES (?,?,?,?)";
		                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
		                    preparedStatement.setString(1, textHoraireS.getText());
		                    preparedStatement.setString(2, textDateDebut.getText());
		                    preparedStatement.setString(3, textDateFin.getText());
		                    preparedStatement.setString(4, textIDSalle.getText());
		                    
		                 

		                    int rowsAffected = preparedStatement.executeUpdate();
		                    
		                    System.out.println("Lignes affectées : " + rowsAffected);
		                    
		    				MenuPrincipal fenetreMenu = new MenuPrincipal();  // Passer d'une fenêtre à une autre
		    				fenetreMenu.setVisible(true);
		                     //FenStagiaire.this.dispose(); //Fermer la fenetre active

		    				
		                } catch (SQLException e3) {
		                    e3.printStackTrace();
		                }
		            } catch (SQLException e2) {
		                e2.printStackTrace();
		                System.out.println("Erreur lors de la connexion");
		            }
		        } catch (ClassNotFoundException e1) {
		            e1.printStackTrace();
		            System.out.println("Erreur lors du chargement du pilote JDBC");
		        }
				
			}
		});
		btnEnregistrer.setForeground(Color.WHITE);
		btnEnregistrer.setFont(new Font("Dialog", Font.BOLD, 15));
		btnEnregistrer.setBackground(new Color(255, 128, 0));
		btnEnregistrer.setBounds(373, 436, 180, 80);
		frame.getContentPane().add(btnEnregistrer);
		
		JButton btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmConnexion = new JFrame("Modifier");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Etes-vous de vouloir Modifier  ces données ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					// Connexion et insertion dans la base de données
					try {
						
			            String jdbcUrl = "jdbc:mysql://localhost/mfc";
			            String user = "root";
			            String password = "Root";

			            // Chargez le pilote JDBC et établissez la connexion
			            Class.forName("com.mysql.cj.jdbc.Driver");
			            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
			                System.out.println("Connecté à la base de données MySQL");

			                // Vous pouvez exécuter vos requêtes SQL ici
			                // Par exemple, insérer des données dans une table :
			                String sql = "UPDATE stagiaires SET Horaire_SE=?,Date_de_debut=?,Date_de_fin=? WHERE IDSE=?"; //Assurez-vous que NomS est unique pour identifier la ligne à mettre à jour
			                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			                    preparedStatement.setString(1, textHoraireS.getText());
			                    preparedStatement.setString(2, textDateDebut.getText());
			                    preparedStatement.setString(3, textDateFin.getText());
			                    preparedStatement.setString(4, textIDSalle.getText());
			                    preparedStatement.setString(5, textIDSession.getText()); // NomS utilisé pour identifier la ligne à mettre à jour


			                    int rowsAffected = preparedStatement.executeUpdate();
			                    JOptionPane.showMessageDialog(frame," ligne(s) affectée(s)."+ rowsAffected );


			    				
			                    System.out.println("Lignes affectées : " + rowsAffected);

			                    
			    				MenuPrincipal fenetreMenu = new MenuPrincipal();  // Passer d'une fenêtre à une autre
			    				fenetreMenu.setVisible(true);
			                     //FenStagiaire.this.dispose(); //Fermer la fenetre active

			    				
			                } catch (SQLException e3) {
			                    e3.printStackTrace();
			                }
			            } catch (SQLException e2) {
			                e2.printStackTrace();
			                System.out.println("Erreur lors de la connexion");
			            }
			        } catch (ClassNotFoundException e1) {
			            e1.printStackTrace();
			            System.out.println("Erreur lors du chargement du pilote JDBC");
			        }
				};
				
			}
		});
		btnModifier.setForeground(Color.WHITE);
		btnModifier.setFont(new Font("Dialog", Font.BOLD, 15));
		btnModifier.setBackground(new Color(255, 128, 0));
		btnModifier.setBounds(591, 436, 180, 80);
		frame.getContentPane().add(btnModifier);
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmConnexion = new JFrame("Supprimer");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Voulez-vous Supprimer ces données ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					// Connexion et insertion dans la base de données
					try {
						
			            String jdbcUrl = "jdbc:mysql://localhost/mfc";
			            String user = "root";
			            String password = "Root";

			            // Chargez le pilote JDBC et établissez la connexion
			            Class.forName("com.mysql.cj.jdbc.Driver");
			            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
			                System.out.println("Connecté à la base de données MySQL");

			                // Vous pouvez exécuter vos requêtes SQL ici
			                // Par exemple, insérer des données dans une table :
			                String sql = "DELETE FROM sessions_de_formation WHERE IDSE=?";
			                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			                    preparedStatement.setString(1, textIDSession.getText()); // Utilisez un identifiant unique pour la suppression
			                    

			                    int rowsAffected2 = preparedStatement.executeUpdate();
			                    JOptionPane.showMessageDialog(frame," ligne(s) affectée(s)."+ rowsAffected2 );

			                    System.out.println("Lignes affectées : " + rowsAffected2);
			                    
			    				MenuPrincipal fenetreMenu = new MenuPrincipal();  // Passer d'une fenêtre à une autre
			    				fenetreMenu.setVisible(true);
			                     //FenStagiaire.this.dispose(); //Fermer la fenetre active

			    				
			                } catch (SQLException e3) {
			                    e3.printStackTrace();
			                }
			            } catch (SQLException e2) {
			                e2.printStackTrace();
			                System.out.println("Erreur lors de la connexion");
			            }
			        } catch (ClassNotFoundException e1) {
			            e1.printStackTrace();
			            System.out.println("Erreur lors du chargement du pilote JDBC");
			        }
				};
				
			}
		});
		btnSupprimer.setForeground(Color.WHITE);
		btnSupprimer.setFont(new Font("Dialog", Font.BOLD, 15));
		btnSupprimer.setBackground(new Color(255, 128, 0));
		btnSupprimer.setBounds(373, 550, 180, 80);
		frame.getContentPane().add(btnSupprimer);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmConnexion = new JFrame("Quitter");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Voulez-vous quitter l'application ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				};
				
			}
		});
		btnQuitter.setForeground(Color.WHITE);
		btnQuitter.setFont(new Font("Dialog", Font.BOLD, 15));
		btnQuitter.setBackground(new Color(255, 128, 0));
		btnQuitter.setBounds(591, 550, 180, 80);
		frame.getContentPane().add(btnQuitter);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(818, 129, 700, 400);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel lblDureef_1 = new JLabel("ID Sessions");
		lblDureef_1.setForeground(Color.WHITE);
		lblDureef_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDureef_1.setBounds(361, 381, 185, 40);
		frame.getContentPane().add(lblDureef_1);
		
		textIDSession = new JTextField();
		textIDSession.setColumns(10);
		textIDSession.setBounds(571, 394, 200, 19);
		frame.getContentPane().add(textIDSession);
		
		JButton btnRecheche = new JButton("Actualiser");
		btnRecheche.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
		            String jdbcUrl = "jdbc:mysql://localhost/mfc";
		            String user = "root";
		            String password = "Root";

		            Class.forName("com.mysql.cj.jdbc.Driver");
		            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
		                System.out.println("Connecté à la base de données MySQL");

		                String sql = "SELECT * FROM sessions_de_formation"; // Supprimez 'order by IDS' si ce n'est pas nécessaire
		                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
		                    ResultSet resultSet = preparedStatement.executeQuery();

		                    // Créer un DefaultTableModel pour stocker les données
		                    DefaultTableModel model = new DefaultTableModel();
		                 // Ajouter les colonnes avec les titres prédéfinis
		                    String[] columnTitles = {"IDSE", "Horaire_SE", "Date_de_debut", "Date_de_fin", "IDSALLE"};
		                    model.setColumnIdentifiers(columnTitles);

		                    // Ajouter les lignes
		                    while (resultSet.next()) {
		                        Object[] row = {
		                            resultSet.getInt("IDSE"),
		                            resultSet.getString("Horaire_SE"),
		                            resultSet.getString("Date_de_debut"),
		                            resultSet.getString("Date_de_fin"),
		                            resultSet.getString("IDSALLE")
		                        };
		                        model.addRow(row);
		                    }
		                    // Mettre à jour le modèle de table existant
		                    table.setModel(model);
		                } catch (SQLException e3) {
		                    e3.printStackTrace();
		                }
		            } catch (SQLException e2) {
		                e2.printStackTrace();
		                System.out.println("Erreur lors de la connexion");
		            }
		        } catch (ClassNotFoundException e1) {
		            e1.printStackTrace();
		            System.out.println("Erreur lors du chargement du pilote JDBC");
		        }
				
			}
		});
		btnRecheche.setForeground(Color.WHITE);
		btnRecheche.setFont(new Font("Dialog", Font.BOLD, 15));
		btnRecheche.setBackground(new Color(255, 128, 0));
		btnRecheche.setBounds(1112, 582, 180, 80);
		frame.getContentPane().add(btnRecheche);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre.jpg"));
		lblNewLabel.setBackground(Color.BLACK);
		lblNewLabel.setBounds(0, 0, 1540, 845);
		frame.getContentPane().add(lblNewLabel);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
