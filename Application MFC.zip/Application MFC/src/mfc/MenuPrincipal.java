package mfc;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;





public class MenuPrincipal {

	private static final long serialVersionUID = 1L;

	private JFrame frame;
	private JFrame frmConnexion;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuPrincipal window = new MenuPrincipal();
					//window.run();
					window.frame.setVisible(true);

					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MenuPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setFrame(new JFrame());
		getFrame().setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\esdra\\Downloads\\Blue Modern Free Academy Logo.png"));
		getFrame().getContentPane().setBackground(new Color(0, 0, 0));
		getFrame().setBounds(0, 0, 1700, 1080);
		getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getFrame().getContentPane().setLayout(null);
		
		
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(255, 128, 0));
		panel.setBounds(0, 0, 1540, 64);
		getFrame().getContentPane().add(panel);
		
		JLabel lblTitreStagiaire = new JLabel("Accueil");
		lblTitreStagiaire.setForeground(Color.WHITE);
		lblTitreStagiaire.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblTitreStagiaire.setBackground(new Color(255, 128, 0));
		lblTitreStagiaire.setBounds(769, 10, 185, 50);
		panel.add(lblTitreStagiaire);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(160, 226, 45, 13);
		getFrame().getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenFormations window = new FenFormations();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
				
				
				
				
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre.gif"));
		btnNewButton_1.setBounds(300, 200, 200, 200);
		getFrame().getContentPane().add(btnNewButton_1);
		
		JButton btnStagiaire = new JButton("");
		btnStagiaire.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                            frame.dispose();


                        	FenStagiaire window = new FenStagiaire();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
				
				

			}
		});
		btnStagiaire.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre (4).png"));
		btnStagiaire.setBounds(600, 200, 200, 200);
		getFrame().getContentPane().add(btnStagiaire);
		
		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                        	
                            frame.dispose();

                        	FenFormateur window = new FenFormateur();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
				
				
			}
		});
		btnNewButton_4.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre (5).png"));
		btnNewButton_4.setBounds(900, 200, 200, 200);
		getFrame().getContentPane().add(btnNewButton_4);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {

                    public void run() {

                        try {
                        	
                        	
                            frame.dispose();

                        	FenSessions window = new FenSessions();

                            window.getFrame().setVisible(true);

                        } catch (Exception ex) {

                            ex.printStackTrace();

                        }

                    }

                });
			}
		});
		button.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre (6).png"));
		button.setBounds(1200, 200, 200, 200);
		getFrame().getContentPane().add(button);
		
		JButton btnNewButton_6 = new JButton("New button");
		btnNewButton_6.setBounds(1212, 200, 85, 21);
		getFrame().getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_2 = new JButton("Quitter");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_2.setForeground(new Color(0, 0, 0));
		btnNewButton_2.setFont(new Font("Dialog", Font.BOLD, 20));
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.setBounds(760, 649, 180, 80);
		getFrame().getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_3 = new JLabel("Formation");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(300, 428, 200, 30);
		getFrame().getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("Stagiaires ");
		lblNewLabel_3_1.setForeground(Color.WHITE);
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3_1.setBounds(600, 428, 200, 30);
		getFrame().getContentPane().add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Formateurs ");
		lblNewLabel_3_1_1.setForeground(Color.WHITE);
		lblNewLabel_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3_1_1.setBounds(900, 428, 200, 30);
		getFrame().getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_3_1_1_1 = new JLabel("Sessions");
		lblNewLabel_3_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_3_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3_1_1_1.setBounds(1200, 428, 200, 30);
		getFrame().getContentPane().add(lblNewLabel_3_1_1_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(new Color(0, 0, 0));
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\esdra\\Downloads\\Design sans titre.jpg"));
		lblNewLabel.setBounds(0, 0, 1540, 845);
		getFrame().getContentPane().add(lblNewLabel);
		
		
		
		
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	
}
