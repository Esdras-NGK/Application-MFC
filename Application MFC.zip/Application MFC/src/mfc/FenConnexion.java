package mfc;

import java.awt.EventQueue;






import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.Toolkit;
// La connexion à la base de données
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class FenConnexion {

	private static final long serialVersionUID = 1L;

	private JFrame frame;
	private JTextField textnom;
	private JPasswordField txtMdp;
	private JFrame frmConnexion;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			
			public void run() {
				try {
					FenConnexion window = new FenConnexion();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			
	        
	        
	        
		});
	}

	/**
	 * Create the application.
	 */
	public FenConnexion() {
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		//setIconImage(Toolkit.getDefaultToolkit().getImage(FenConnexion.class.getResource("/images/logo MFC.png")));


		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\esdra\\Downloads\\Blue Modern Free Academy Logo.png"));
		frame.getContentPane().setBackground(new Color(0, 0, 0));
		frame.setBounds(300, 200, 1000, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
        
        
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(255, 128, 0));
		panel.setBounds(0, 0, 1540, 64);
		frame.getContentPane().add(panel);
		
		JLabel lblTitreStagiaire = new JLabel("Connexion");
		lblTitreStagiaire.setForeground(Color.WHITE);
		lblTitreStagiaire.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblTitreStagiaire.setBackground(new Color(255, 128, 0));
		lblTitreStagiaire.setBounds(428, 10, 185, 50);
		panel.add(lblTitreStagiaire);
		
		JLabel lblNomstagiaire = new JLabel("Nom d'utilisateur");
		lblNomstagiaire.setForeground(Color.WHITE);
		lblNomstagiaire.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNomstagiaire.setBounds(270, 137, 185, 40);
		frame.getContentPane().add(lblNomstagiaire);
		
		textnom = new JTextField();
		textnom.setColumns(10);
		textnom.setBounds(480, 151, 200, 19);
		frame.getContentPane().add(textnom);
		
		JLabel lblStagiaire = new JLabel("Mot de passe");
		lblStagiaire.setForeground(Color.WHITE);
		lblStagiaire.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblStagiaire.setBounds(270, 187, 185, 40);
		frame.getContentPane().add(lblStagiaire);
		
		JButton btnConnexion = new JButton("Connexion");
		btnConnexion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				// Connexion et insertion dans la base de données
				try {
					
		            String jdbcUrl = "jdbc:mysql://localhost/mfc";
		            String user = "root";
		            String password = "Root";

		            // Chargez le pilote JDBC et établissez la connexion
		            Class.forName("com.mysql.cj.jdbc.Driver");
		            try (Connection connection = DriverManager.getConnection(jdbcUrl, user, password)) {
		                System.out.println("Connecté à la base de données MySQL");

		                // Vous pouvez exécuter vos requêtes SQL ici
		                String sql = "SELECT * FROM users WHERE nom = ? AND Mot_de_passe = ?";
		                int rowsAffected = 0; // Initialiser la variable rowsAffected à l'extérieur du bloc try

		                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
		                    // Testez le mot de passe
		                    preparedStatement.setString(1, textnom.getText());
		                    preparedStatement.setString(2, new String(txtMdp.getPassword()));
		                    
		                    ResultSet resultSet = preparedStatement.executeQuery();
		                    
		                    if (resultSet.next()) {
		                        // Si l'utilisateur est trouvé dans la base de données
		                        // Effectuer d'autres opérations nécessaires
		                        
		                        // Exemple de mise à jour de la base de données
		                        // rowsAffected = preparedStatement.executeUpdate();
		                        
		                        // Code pour passer à une autre fenêtre après la connexion réussie
		                    	EventQueue.invokeLater(new Runnable() {

		                            public void run() {

		                                try {

		                                    frame.dispose();
		                                    MenuPrincipal window = new MenuPrincipal();
		                                    window.getFrame().setVisible(true);

		                                } catch (Exception ex) {

		                                    ex.printStackTrace();

		                                }

		                            }

		                        });

			    				
		                    } else {
		                        JOptionPane.showMessageDialog(null, "Informations incorrectes", "Erreur de connexion", JOptionPane.ERROR_MESSAGE);
		                        /*txtMDP.setText(null);
		                        txtUtilisateur.setText(null);*/
		                    }

		                
		                
		                    

		                    
		                   /* EventQueue.invokeLater(new Runnable() {

		                        public void run() {

		                            try {

		                                MenuPrincipal window = new MenuPrincipal();

		            					window.frame.setVisible(true);

		                            } catch (Exception ex) {

		                                ex.printStackTrace();

		                            }

		                        }

		                    });
*/
		                

		    				
		                } catch (SQLException e3) {
		                    e3.printStackTrace();
		                }
		            } catch (SQLException e2) {
		                e2.printStackTrace();
		                System.out.println("Erreur lors de la connexion");
		            }
		        } catch (ClassNotFoundException e1) {
		            e1.printStackTrace();
		            System.out.println("Erreur lors du chargement du pilote JDBC");
		        }
				
				
			}
			
		});
		btnConnexion.setForeground(Color.WHITE);
		btnConnexion.setFont(new Font("Dialog", Font.BOLD, 15));
		btnConnexion.setBackground(new Color(255, 128, 0));
		btnConnexion.setBounds(282, 260, 180, 80);
		frame.getContentPane().add(btnConnexion);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmConnexion = new JFrame("Quitter");
				if(JOptionPane.showConfirmDialog(frmConnexion, "Voulez-vous quitter l'application ?", "Page de connexion", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnQuitter.setForeground(Color.WHITE);
		btnQuitter.setFont(new Font("Dialog", Font.BOLD, 15));
		btnQuitter.setBackground(new Color(255, 128, 0));
		btnQuitter.setBounds(500, 260, 180, 80);
		frame.getContentPane().add(btnQuitter);
		
		txtMdp = new JPasswordField();
		txtMdp.setBounds(480, 202, 200, 19);
		frame.getContentPane().add(txtMdp);
	}

	protected void dispose() {
		// TODO Auto-generated method stub
		
	}
}
