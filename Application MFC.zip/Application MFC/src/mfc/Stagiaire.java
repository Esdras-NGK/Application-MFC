package mfc;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

import com.mysql.cj.xdevapi.Result;
import javax.swing.JPasswordField;
import java.awt.Color;
import javax.swing.JPanel;
import java.awt.Toolkit;

public class Stagiaire {

	private JFrame frame;

	
    // Les variables nécessaires

	static Connection conn;
	static Statement State;
	static ResultSet result;
	static ResultSetMetaData resultSetMeta;
	//static Object[][] donn;
	//static String[] champs;
	static Object[] val;
	static String tableBDD = "compte";
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Stagiaire window = new Stagiaire();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JTextField textField;
	private JTextField textNomS;
	private JTextField textPrenomS;
	private JTextField textTelS;
	private JTextField textAdresseS;
	private JTextField textMailS;
	private JTextField textEntrepriseS;
	private JPasswordField txtMdp;
	private JPasswordField txtCmdp;
	public Stagiaire() {
		initialize();
		Connect();
		table_load();	
			
			
	}
	/**
	 * Create the application.
	 */
	private void Connect() {
		// TODO Auto-generated method stub
		// Le code à exécuter est à insérer ici.

				/*
				 *  Informations de connexion, pour connecter l'application
				 *  à la BDD
				 */
s
				String BDD = "mfc";
				String url = "jdbc:mysql://localhost/" + BDD;
				String user = "root";
				String passwd = "";
				/*
				 *  On vérifie bien que la connexion avec la base de données
				 *  s'effectue sans aucun problème.
				 */
				try {
					
					//Stagiaire window = new Stagiaire();
		            //window.Connect(); // Appel à la méthode run() pour initialiser la connexion
		            //window.frame.setVisible(true);
					Class.forName("com.mysql.cj.jdbc.Driver");
					con = DriverManager.getConnection(url, user, passwd);
					System.out.println("Connecter");
					
					
				} catch (Exception e) {
					e.printStackTrace();
					System.out.print("Erreur");
				}
				
				
			
	}

	
        
	
	
	public void table_load()
	{

		try {
			
			pst = con.prepareStatement("SELECT * FROM stagiaires order by IDS");
			rs = pst.executeQuery();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\esdra\\Downloads\\Blue Modern Free Academy Logo.png"));
		frame.getContentPane().setBackground(new Color(0, 0, 0));
		frame.getContentPane().setForeground(new Color(0, 0, 0));
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 18));
		frame.setBounds(100, 100, 1720, 1080);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblIdLivre = new JLabel("Id stagiaire");
		lblIdLivre.setForeground(Color.WHITE);
		lblIdLivre.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblIdLivre.setBounds(703, 521, 185, 40);
		frame.getContentPane().add(lblIdLivre);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(869, 534, 200, 19);
		frame.getContentPane().add(textField);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(255, 128, 0));
		panel.setBounds(0, 0, 1540, 64);
		frame.getContentPane().add(panel);
		
		JLabel lblTitreStagiaire = new JLabel("STAGIAIRE");
		lblTitreStagiaire.setForeground(Color.WHITE);
		lblTitreStagiaire.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblTitreStagiaire.setBackground(new Color(255, 128, 0));
		lblTitreStagiaire.setBounds(728, 10, 185, 50);
		panel.add(lblTitreStagiaire);
		
		JLabel lblNomstagiaire = new JLabel("Nom du Stagiaire");
		lblNomstagiaire.setForeground(Color.WHITE);
		lblNomstagiaire.setFont(new Font("Dialog", Font.PLAIN, 16));
		lblNomstagiaire.setBounds(253, 108, 185, 40);
		frame.getContentPane().add(lblNomstagiaire);
		
		JLabel lblStagiaire = new JLabel("Prenom Stagiaire");
		lblStagiaire.setForeground(Color.WHITE);
		lblStagiaire.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblStagiaire.setBounds(253, 158, 185, 40);
		frame.getContentPane().add(lblStagiaire);
		
		JLabel lblTel = new JLabel("Tel Stagiare");
		lblTel.setForeground(Color.WHITE);
		lblTel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTel.setBounds(253, 208, 185, 40);
		frame.getContentPane().add(lblTel);
		
		JLabel lblAdresse = new JLabel("Adresse Stagiare");
		lblAdresse.setForeground(Color.WHITE);
		lblAdresse.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblAdresse.setBounds(253, 258, 185, 40);
		frame.getContentPane().add(lblAdresse);
		
		JLabel lblMail = new JLabel("Mail Stagiare");
		lblMail.setForeground(Color.WHITE);
		lblMail.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblMail.setBounds(253, 308, 185, 40);
		frame.getContentPane().add(lblMail);
		
		JLabel lblEntreprise = new JLabel("Entreprise ");
		lblEntreprise.setForeground(Color.WHITE);
		lblEntreprise.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEntreprise.setBounds(253, 358, 185, 40);
		frame.getContentPane().add(lblEntreprise);
		
		JLabel lblMdp = new JLabel("Mot de passe");
		lblMdp.setForeground(Color.WHITE);
		lblMdp.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblMdp.setBounds(253, 408, 185, 40);
		frame.getContentPane().add(lblMdp);
		
		JLabel lblCmdp = new JLabel("Confirmé le  mot de passe");
		lblCmdp.setForeground(Color.WHITE);
		lblCmdp.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblCmdp.setBounds(253, 458, 200, 40);
		frame.getContentPane().add(lblCmdp);
		
		textNomS = new JTextField();
		textNomS.setColumns(10);
		textNomS.setBounds(463, 122, 200, 19);
		frame.getContentPane().add(textNomS);
		
		textPrenomS = new JTextField();
		textPrenomS.setColumns(10);
		textPrenomS.setBounds(463, 171, 200, 19);
		frame.getContentPane().add(textPrenomS);
		
		textTelS = new JTextField();
		textTelS.setColumns(10);
		textTelS.setBounds(463, 221, 200, 19);
		frame.getContentPane().add(textTelS);
		
		textAdresseS = new JTextField();
		textAdresseS.setColumns(10);
		textAdresseS.setBounds(463, 271, 200, 19);
		frame.getContentPane().add(textAdresseS);
		
		textMailS = new JTextField();
		textMailS.setColumns(10);
		textMailS.setBounds(463, 321, 200, 19);
		frame.getContentPane().add(textMailS);
		
		textEntrepriseS = new JTextField();
		textEntrepriseS.setColumns(10);
		textEntrepriseS.setBounds(463, 371, 200, 19);
		frame.getContentPane().add(textEntrepriseS);
		
		txtMdp = new JPasswordField();
		txtMdp.setBounds(463, 421, 200, 19);
		frame.getContentPane().add(txtMdp);
		
		txtCmdp = new JPasswordField();
		txtCmdp.setBounds(463, 471, 200, 19);
		frame.getContentPane().add(txtCmdp);
		
		JButton btnNewButton = new JButton("Enregistrer");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Saisie des variables
				String nom, prenom, tel, Adresse, mail, entreprise, motdepasse, cmotdepasse;
				
				
				
				nom = textNomS.getText();
				prenom = textPrenomS.getText();
				tel = textTelS.getText();
				Adresse = textAdresseS.getText();
				mail = textMailS.getText();
				entreprise = textEntrepriseS.getText();
				motdepasse = txtMdp.getText();
				cmotdepasse = txtCmdp.getText();
				
				 try {
				        pst = con.prepareStatement("INSERT INTO stagiaires(NomS, PrenomS, Tel_S, Adresse_S, Mail_S, Entreprise, mdp, cmdp) VALUES (?,?,?,?,?,?,?,?)");
				        pst.setString(1, nom);
				        pst.setString(2, prenom);
				        pst.setString(3, tel);
				        pst.setString(4, Adresse);
				        pst.setString(5, mail);
				        pst.setString(6, entreprise);
				        pst.setString(7, motdepasse);
				        pst.setString(8, cmotdepasse);
				        JOptionPane.showMessageDialog(null, "Le stagiaire ajouter");

				        textNomS.setText("");
				        textPrenomS.setText("");
				        textTelS.setText("");
				        textAdresseS.setText("");
				        textMailS.setText("");
				        textEntrepriseS.setText("");
				        txtMdp.setText("");
				        txtCmdp.setText("");
				        textNomS.requestFocus();
				    } catch (Exception e2) {
				        e2.printStackTrace();
				    }
				
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton.setBackground(new Color(255, 128, 0));
		btnNewButton.setBounds(264, 567, 180, 80);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("New button");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_2.setBackground(new Color(255, 128, 0));
		btnNewButton_2.setBounds(482, 567, 180, 80);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("Effacer");
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Dialog", Font.BOLD, 15));
		btnNewButton_1.setBackground(new Color(255, 128, 0));
		btnNewButton_1.setBounds(264, 681, 180, 80);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.setForeground(Color.WHITE);
		btnQuitter.setFont(new Font("Dialog", Font.BOLD, 15));
		btnQuitter.setBackground(new Color(255, 128, 0));
		btnQuitter.setBounds(482, 681, 180, 80);
		frame.getContentPane().add(btnQuitter);
	}
}

import java.awt.EventQueue;

import javax.swing.JFrame;

public class Stagiaire {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Stagiaire window = new Stagiaire();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Stagiaire() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
